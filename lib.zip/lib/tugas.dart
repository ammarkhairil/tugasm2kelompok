import 'dart:math';

import 'package:flutter/material.dart';
import 'dart:io';

import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyStreamPage(),
    );
  }
}

class MyStreamPage extends StatefulWidget {
  @override
  _MyStreamPageState createState() => _MyStreamPageState();
}

class _MyStreamPageState extends State<MyStreamPage> {
  late StreamController<double> _streamController;
  late Stream<double> myStream;
  double _currentValue = 2 ;

  @override
  void initState() {
    super.initState();

    _streamController = StreamController<double>();
    myStream = _streamController.stream;

    // Fungsi async yang akan mengirim nilai setiap 2 detik
    Future<void> sendData() async {
      while (true) {
        await Future.delayed(Duration(seconds: 2));
        _currentValue = Random().nextDouble();;

        _streamController.add(_currentValue);
      }
    }

    // Memulai pengiriman data
    sendData();
  }

  @override
  void dispose() {
    _streamController.close(); // Menutup StreamController saat widget di-dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stream Example'),
      ),
      body: Center(
        child: StreamBuilder<double>(
          stream: myStream,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Text('Data: ${snapshot.data.toString()}');
            } else {
              return CircularProgressIndicator();
            }
          },
        ),
      ),
    );
  }
}
